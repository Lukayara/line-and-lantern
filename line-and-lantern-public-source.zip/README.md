# Line & Lantern

An original, portrait-first Godot 4 railway-management game vertical slice. The project uses code-drawn miniature scenery to stay sharp at every iPhone resolution and avoid dependency-heavy placeholder art.

## Run locally

Open `project.godot` in Godot 4.3 or newer and press Run. The game starts at the main menu; tap Continue to enter the railway map.

The playable slice includes a functioning starting route, moving trains, route construction, fleet purchases, station upgrades, XP/level progression, objectives, a brief tutorial, settings, touch pan/zoom, friendly error states, and local persistence in `user://line_and_lantern_save.json`.

## iPhone / IPA later

The project is already configured for portrait orientation and canvas-item scaling. To create an installable IPA later, use a Mac with Xcode and an Apple Developer signing account:

1. Install Godot iOS export templates.
2. In Godot, add an iOS export preset and set your bundle identifier, version, team, and signing profile.
3. Export an Xcode project, open it in Xcode, choose a device or archive destination, then Archive and distribute the IPA through TestFlight, Ad Hoc, or a development profile.

For automated builds, the same export can be handled by a macOS CI runner with the signing assets stored as secrets.
