extends Node

signal state_changed
signal reward_earned(amount: int, message: String)
signal notice(message: String)
signal level_up(level: int)

const SAVE_PATH := "user://line_and_lantern_save.json"
const TRAIN_TYPES := {
	"starter": {"name":"Willow Railcar", "price":0, "speed":0.055, "capacity":18, "maintenance":5, "color":Color("#3d7e86"), "accent":Color("#f4e8b4"), "unlock":1},
	"regional": {"name":"Cedar Regional", "price":950, "speed":0.080, "capacity":42, "maintenance":12, "color":Color("#bd5d43"), "accent":Color("#fff0ce"), "unlock":2},
	"express": {"name":"Northstar Express", "price":2450, "speed":0.115, "capacity":76, "maintenance":23, "color":Color("#3c5c9c"), "accent":Color("#f3c95e"), "unlock":4}
}
const STATION_TEMPLATE := {
	"meadow": {"name":"Meadowfield", "pos":Vector2(0.25,0.70), "kind":"village", "demand":18, "level":1, "unlocked":true, "color":Color("#d9a76a")},
	"briar": {"name":"Briarwick", "pos":Vector2(0.49,0.46), "kind":"town", "demand":32, "level":1, "unlocked":true, "color":Color("#8c5967")},
	"harbor": {"name":"Harborview", "pos":Vector2(0.76,0.27), "kind":"city", "demand":60, "level":1, "unlocked":true, "color":Color("#456f9b")},
	"summit": {"name":"Summit Cross", "pos":Vector2(0.77,0.68), "kind":"town", "demand":38, "level":1, "unlocked":false, "color":Color("#6e7e4f")}
}

var money := 1850
var level := 1
var xp := 35
var total_passengers := 0
var total_earned := 0
var stations: Dictionary = {}
var trains: Array = []
var routes: Array = []
var settings := {"music":0.65, "sfx":0.8, "vibration":true, "notifications":true, "quality":"High"}
var tutorial_step := 0
var elapsed := 0.0
var next_train_number := 2
var completed_missions: Dictionary = {}

func _ready() -> void:
	load_game()

func _process(delta: float) -> void:
	elapsed += delta
	var changed := false
	for route in routes:
		if route.train_id == "":
			continue
		var train = get_train(route.train_id)
		if train.is_empty():
			continue
		route.progress += delta * TRAIN_TYPES[train.type].speed
		if route.progress >= 1.0:
			route.progress -= 1.0
			complete_trip(route, train)
			changed = true
	if changed or int(elapsed * 2.0) % 2 == 0:
		state_changed.emit()

func reset_game() -> void:
	money = 1850
	level = 1
	xp = 35
	total_passengers = 0
	total_earned = 0
	stations = STATION_TEMPLATE.duplicate(true)
	trains = [{"id":"train_1", "type":"starter", "route_id":"route_1"}]
	routes = [{"id":"route_1", "origin":"meadow", "destination":"briar", "train_id":"train_1", "progress":0.22, "trips":0}]
	settings = {"music":0.65, "sfx":0.8, "vibration":true, "notifications":true, "quality":"High"}
	tutorial_step = 0
	next_train_number = 2
	completed_missions = {}
	save_game()
	state_changed.emit()

func get_train(train_id: String) -> Dictionary:
	for train in trains:
		if train.id == train_id:
			return train
	return {}

func get_route(route_id: String) -> Dictionary:
	for route in routes:
		if route.id == route_id:
			return route
	return {}

func get_available_trains() -> Array:
	var available: Array = []
	for train in trains:
		if train.route_id == "":
			available.append(train)
	return available

func buy_train(type: String) -> bool:
	if not TRAIN_TYPES.has(type):
		return false
	var info: Dictionary = TRAIN_TYPES[type]
	if level < info.unlock:
		notice.emit("Reach company level %d to unlock this train." % info.unlock)
		return false
	if money < info.price:
		notice.emit("Not enough funds for %s." % info.name)
		return false
	money -= info.price
	var id := "train_%d" % next_train_number
	next_train_number += 1
	trains.append({"id":id, "type":type, "route_id":""})
	gain_xp(16)
	reward_earned.emit(0, "%s joined your fleet" % info.name)
	save_game()
	state_changed.emit()
	return true

func create_route(origin: String, destination: String, train_id: String) -> bool:
	if origin == destination or not stations.has(origin) or not stations.has(destination):
		notice.emit("Choose two different stations.")
		return false
	if train_id == "" or get_train(train_id).is_empty():
		notice.emit("Assign an available train first.")
		return false
	if get_train(train_id).route_id != "":
		notice.emit("That train is already assigned.")
		return false
	var cost := route_construction_cost(origin, destination)
	if money < cost:
		notice.emit("You need %d more coins to build this route." % (cost - money))
		return false
	money -= cost
	var route_id := "route_%d" % (routes.size() + 1)
	routes.append({"id":route_id, "origin":origin, "destination":destination, "train_id":train_id, "progress":0.0, "trips":0})
	for train in trains:
		if train.id == train_id:
			train.route_id = route_id
	gain_xp(25)
	reward_earned.emit(0, "A new route is now open")
	if tutorial_step < 2:
		tutorial_step = 2
	save_game()
	state_changed.emit()
	return true

func route_construction_cost(origin: String, destination: String) -> int:
	return 170 + int(stations[origin].pos.distance_to(stations[destination].pos) * 800.0)

func route_distance(origin: String, destination: String) -> int:
	return int(stations[origin].pos.distance_to(stations[destination].pos) * 210.0) + 8

func route_income(route: Dictionary, train: Dictionary) -> int:
	var demand: int = int((stations[route.origin].demand + stations[route.destination].demand) / 2)
	var cap: int = int(TRAIN_TYPES[train.type].capacity)
	var distance: int = route_distance(route.origin, route.destination)
	var upgrade_bonus: int = int(stations[route.origin].level + stations[route.destination].level)
	return min(demand + upgrade_bonus * 3, cap) * max(2, distance / 6)

func complete_trip(route: Dictionary, train: Dictionary) -> void:
	var gross: int = route_income(route, train)
	var profit: int = max(1, gross - int(TRAIN_TYPES[train.type].maintenance))
	money += profit
	total_earned += profit
	var riders: int = min(int(TRAIN_TYPES[train.type].capacity), int((stations[route.origin].demand + stations[route.destination].demand) / 2))
	total_passengers += riders
	route.trips += 1
	gain_xp(4)
	reward_earned.emit(profit, "%d passengers arrived safely" % riders)
	check_missions()
	save_game()

func upgrade_station(station_id: String) -> bool:
	if not stations.has(station_id):
		return false
	var station: Dictionary = stations[station_id]
	if station.level >= 4:
		notice.emit("This station is already a major hub.")
		return false
	var cost: int = 240 * int(station.level)
	if money < cost:
		notice.emit("Not enough funds for this upgrade.")
		return false
	money -= cost
	station.level += 1
	station.demand += 10
	gain_xp(14)
	reward_earned.emit(0, "%s is now level %d" % [station.name, station.level])
	check_missions()
	save_game()
	state_changed.emit()
	return true

func unlock_station(station_id: String) -> bool:
	if not stations.has(station_id) or stations[station_id].unlocked:
		return false
	var cost := 500
	if money < cost:
		notice.emit("You need %d coins to survey this region." % cost)
		return false
	money -= cost
	stations[station_id].unlocked = true
	gain_xp(35)
	reward_earned.emit(0, "%s is now on the map" % stations[station_id].name)
	save_game()
	state_changed.emit()
	return true

func gain_xp(amount: int) -> void:
	xp += amount
	var threshold := level * 100
	if xp >= threshold:
		xp -= threshold
		level += 1
		money += 180
		level_up.emit(level)

func check_missions() -> void:
	if total_passengers >= 100 and not completed_missions.has("passengers"):
		completed_missions.passengers = true
		money += 250
		reward_earned.emit(250, "Mission complete: 100 passengers")
	if routes.size() >= 2 and not completed_missions.has("routes"):
		completed_missions.routes = true
		money += 180
		reward_earned.emit(180, "Mission complete: Network builder")

func save_game() -> void:
	var station_save := {}
	for station_id in stations:
		var station: Dictionary = stations[station_id]
		station_save[station_id] = {"level":station.level, "demand":station.demand, "unlocked":station.unlocked}
	var payload := {"money":money, "level":level, "xp":xp, "total_passengers":total_passengers, "total_earned":total_earned, "stations":station_save, "trains":trains, "routes":routes, "settings":settings, "tutorial_step":tutorial_step, "next_train_number":next_train_number, "completed_missions":completed_missions}
	var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if file:
		file.store_string(JSON.stringify(payload))
	else:
		notice.emit("Your progress could not be saved just now.")

func load_game() -> void:
	if not FileAccess.file_exists(SAVE_PATH):
		reset_game()
		return
	var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
	var json := JSON.new()
	if not file or json.parse(file.get_as_text()) != OK or not json.data is Dictionary:
		reset_game()
		return
	var data: Dictionary = json.data
	money = data.get("money", 1850)
	level = data.get("level", 1)
	xp = data.get("xp", 35)
	total_passengers = data.get("total_passengers", 0)
	total_earned = data.get("total_earned", 0)
	stations = STATION_TEMPLATE.duplicate(true)
	var saved_stations: Dictionary = data.get("stations", {})
	for station_id in saved_stations:
		if not stations.has(station_id):
			continue
		var saved: Dictionary = saved_stations[station_id]
		stations[station_id].level = int(saved.get("level", stations[station_id].level))
		stations[station_id].demand = int(saved.get("demand", stations[station_id].demand))
		stations[station_id].unlocked = bool(saved.get("unlocked", stations[station_id].unlocked))
	trains = data.get("trains", [])
	routes = data.get("routes", [])
	settings = data.get("settings", settings)
	tutorial_step = data.get("tutorial_step", 0)
	next_train_number = data.get("next_train_number", 2)
	completed_missions = data.get("completed_missions", {})
