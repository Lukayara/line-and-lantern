extends Control

const MapViewScene := preload("res://scripts/MapView.gd")

var map_view: Control
var hud: Control
var sheet: PanelContainer
var modal: Control
var toast: PanelContainer
var toast_label: Label
var level_text_label: Label
var xp_bar: ProgressBar
var money_text_label: Label
var selected_station := ""
var route_origin := ""
var route_destination := ""
var route_build_mode := false
var active_tab := "Map"

var ink := Color("#243f43")
var paper := Color("#fffaf0")
var coral := Color("#c75d4c")
var gold := Color("#dcae53")
var moss := Color("#527b62")

func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_build_world()
	_build_hud()
	_build_sheet()
	_build_toast()
	GameState.state_changed.connect(refresh)
	GameState.reward_earned.connect(_on_reward)
	GameState.notice.connect(show_toast)
	GameState.level_up.connect(_on_level_up)
	refresh()
	show_main_menu()

func _build_world() -> void:
	map_view = MapViewScene.new()
	map_view.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	map_view.offset_top = 0
	map_view.offset_bottom = 0
	map_view.station_pressed.connect(_on_station_pressed)
	add_child(map_view)

func _panel_style(color: Color, radius := 18, border := Color.TRANSPARENT, border_width := 0, shadow := true) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.corner_radius_top_left = radius
	style.corner_radius_top_right = radius
	style.corner_radius_bottom_left = radius
	style.corner_radius_bottom_right = radius
	style.border_color = border
	style.border_width_left = border_width
	style.border_width_right = border_width
	style.border_width_top = border_width
	style.border_width_bottom = border_width
	style.content_margin_left = 12
	style.content_margin_right = 12
	style.content_margin_top = 9
	style.content_margin_bottom = 9
	if shadow:
		style.shadow_color = Color(0.08,0.16,0.17,.20)
		style.shadow_size = 7
		style.shadow_offset = Vector2(0,3)
	return style

func _label(text: String, size := 15, color := ink) -> Label:
	var label := Label.new()
	label.text = text
	label.add_theme_font_size_override("font_size", size)
	label.add_theme_color_override("font_color", color)
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	return label

func _button(text: String, kind := "primary") -> Button:
	var button := Button.new()
	button.text = text
	button.custom_minimum_size = Vector2(0,48)
	button.add_theme_font_size_override("font_size", 15)
	button.add_theme_stylebox_override("normal", _panel_style(coral if kind == "primary" else paper, 14, Color("#e9dabc") if kind != "primary" else coral, 1, kind == "primary"))
	button.add_theme_stylebox_override("hover", _panel_style(Color("#b94d40") if kind == "primary" else Color("#fffdf7"), 14, Color("#e9dabc"), 1))
	button.add_theme_stylebox_override("pressed", _panel_style(Color("#a94139") if kind == "primary" else Color("#f2e6cd"), 14))
	button.add_theme_color_override("font_color", Color.WHITE if kind == "primary" else ink)
	button.button_down.connect(func():
		var tween := create_tween()
		tween.tween_property(button, "scale", Vector2(.96,.96), .06)
	)
	button.button_up.connect(func():
		var tween := create_tween()
		tween.tween_property(button, "scale", Vector2.ONE, .1)
	)
	return button

func _build_hud() -> void:
	hud = Control.new()
	hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(hud)
	var top := HBoxContainer.new()
	top.name = "TopBar"
	top.set_anchors_preset(Control.PRESET_TOP_WIDE)
	top.offset_left = 16; top.offset_right = -16; top.offset_top = 52; top.offset_bottom = 102
	top.add_theme_constant_override("separation", 9)
	hud.add_child(top)
	var level_card := PanelContainer.new()
	level_card.name = "LevelCard"
	level_card.custom_minimum_size = Vector2(148,50)
	level_card.add_theme_stylebox_override("panel", _panel_style(paper,16))
	var level_box := VBoxContainer.new(); level_box.size_flags_horizontal=Control.SIZE_EXPAND_FILL; level_box.add_theme_constant_override("separation",0)
	var level_line := HBoxContainer.new()
	var crest := _label("L", 14, paper); crest.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; crest.custom_minimum_size = Vector2(24,24)
	crest.add_theme_stylebox_override("normal", _panel_style(moss,12,moss,0,false))
	level_line.add_child(crest)
	var level_label := _label("COMPANY LEVEL 1",11,ink); level_label.name="Text"; level_label.size_flags_horizontal=Control.SIZE_EXPAND_FILL; level_label.autowrap_mode=TextServer.AUTOWRAP_OFF; level_text_label=level_label; level_line.add_child(level_label)
	level_box.add_child(level_line)
	var xp := ProgressBar.new(); xp.name="XP"; xp_bar=xp; xp.max_value=100; xp.value=35; xp.show_percentage=false; xp.custom_minimum_size=Vector2(116,6)
	xp.add_theme_stylebox_override("background",_panel_style(Color("#ebdfc8"),4,Color.TRANSPARENT,0,false)); xp.add_theme_stylebox_override("fill",_panel_style(gold,4,Color.TRANSPARENT,0,false))
	level_box.add_child(xp); level_card.add_child(level_box); top.add_child(level_card)
	var spacer := Control.new(); spacer.size_flags_horizontal=Control.SIZE_EXPAND_FILL; top.add_child(spacer)
	var money_card := PanelContainer.new(); money_card.name="MoneyCard"; money_card.custom_minimum_size=Vector2(128,50); money_card.add_theme_stylebox_override("panel",_panel_style(paper,16))
	var money_text := _label("COINS\n1,850", 12, ink); money_text.name="Text"; money_text.size_flags_horizontal=Control.SIZE_EXPAND_FILL; money_text.autowrap_mode=TextServer.AUTOWRAP_OFF; money_text_label=money_text; money_text.horizontal_alignment=HORIZONTAL_ALIGNMENT_RIGHT; money_card.add_child(money_text); top.add_child(money_card)
	var pause := _button("II", "secondary"); pause.custom_minimum_size=Vector2(50,50); pause.mouse_filter=Control.MOUSE_FILTER_STOP; pause.pressed.connect(show_pause); top.add_child(pause)
	var nav := HBoxContainer.new()
	nav.name="Nav"
	nav.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	nav.offset_left=7; nav.offset_right=-7; nav.offset_top=7; nav.offset_bottom=-7
	nav.add_theme_constant_override("separation",5)
	var nav_bg := PanelContainer.new(); nav_bg.name="NavBackground"; nav_bg.set_anchors_preset(Control.PRESET_BOTTOM_WIDE); nav_bg.offset_left=14; nav_bg.offset_right=-14; nav_bg.offset_top=-92; nav_bg.offset_bottom=-28; nav_bg.add_theme_stylebox_override("panel",_panel_style(paper,20)); hud.add_child(nav_bg)
	for tab in ["Map","Trains","Routes","Stations","Company"]:
		var nav_button := _button(tab,"secondary"); nav_button.name="Nav"+tab; nav_button.size_flags_horizontal=Control.SIZE_EXPAND_FILL; nav_button.mouse_filter=Control.MOUSE_FILTER_STOP
		nav_button.pressed.connect(func(): show_tab(tab))
		nav.add_child(nav_button)
	nav_bg.add_child(nav)

func _build_sheet() -> void:
	sheet = PanelContainer.new()
	sheet.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
	sheet.offset_left=10; sheet.offset_right=-10; sheet.offset_top=-510; sheet.offset_bottom=-104
	sheet.add_theme_stylebox_override("panel",_panel_style(paper,22))
	sheet.visible=false
	add_child(sheet)

func _build_toast() -> void:
	toast=PanelContainer.new(); toast.set_anchors_preset(Control.PRESET_CENTER_TOP); toast.offset_left=-145; toast.offset_right=145; toast.offset_top=114; toast.offset_bottom=162
	toast.add_theme_stylebox_override("panel",_panel_style(ink,15,Color.TRANSPARENT,0,true)); toast.mouse_filter=Control.MOUSE_FILTER_IGNORE
	toast_label=_label("",13,Color.WHITE); toast_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; toast.add_child(toast_label); toast.visible=false; add_child(toast)

func refresh() -> void:
	if not is_instance_valid(hud): return
	level_text_label.text = "COMPANY LEVEL %d" % GameState.level
	xp_bar.value=GameState.xp; xp_bar.max_value=GameState.level*100
	money_text_label.text = "COINS\n%d" % GameState.money
	if map_view: map_view.focus_station=selected_station
	if sheet.visible and active_tab != "Map": show_tab(active_tab)

func _clear_sheet() -> VBoxContainer:
	for child in sheet.get_children(): child.queue_free()
	var box := VBoxContainer.new(); box.add_theme_constant_override("separation",10); box.add_theme_constant_override("margin_left",16); box.add_theme_constant_override("margin_right",16); box.add_theme_constant_override("margin_top",15); box.add_theme_constant_override("margin_bottom",14)
	sheet.add_child(box)
	return box

func _show_sheet() -> void:
	sheet.visible=true; sheet.modulate.a=0.0; sheet.position.y += 20
	var tween:=create_tween(); tween.set_parallel(); tween.tween_property(sheet,"modulate:a",1.0,.16); tween.tween_property(sheet,"position:y",sheet.position.y-20,.2).set_trans(Tween.TRANS_QUINT).set_ease(Tween.EASE_OUT)

func close_sheet() -> void:
	sheet.visible=false; selected_station=""; route_build_mode=false; route_origin=""; route_destination=""

func show_tab(tab: String) -> void:
	active_tab=tab
	if tab == "Map": close_sheet(); return
	route_build_mode=false
	var box := _clear_sheet()
	var header := HBoxContainer.new(); var title:=_label(tab,22,ink); title.size_flags_horizontal=Control.SIZE_EXPAND_FILL; header.add_child(title)
	var close:=_button("X","secondary"); close.custom_minimum_size=Vector2(42,42); close.pressed.connect(close_sheet); header.add_child(close); box.add_child(header)
	if tab == "Trains": _fill_trains(box)
	elif tab == "Routes": _fill_routes(box)
	elif tab == "Stations": _fill_stations(box)
	else: _fill_company(box)
	_show_sheet()

func _divider(parent: Control) -> void:
	var line:=ColorRect.new(); line.color=Color("#e9dcc3"); line.custom_minimum_size=Vector2(0,1); parent.add_child(line)

func _fill_trains(box: VBoxContainer) -> void:
	box.add_child(_label("Fleet and rolling stock",13,Color("#6d7770")))
	for type in GameState.TRAIN_TYPES:
		var info: Dictionary=GameState.TRAIN_TYPES[type]
		var card:=PanelContainer.new(); card.add_theme_stylebox_override("panel",_panel_style(Color("#fffdf7"),14,Color("#eadcc1"),1,false)); box.add_child(card)
		var row:=HBoxContainer.new(); row.add_theme_constant_override("separation",10); card.add_child(row)
		var badge:=Label.new(); badge.text=""; badge.custom_minimum_size=Vector2(52,45); badge.add_theme_stylebox_override("normal",_panel_style(info.color,10,Color.TRANSPARENT,0,false)); row.add_child(badge)
		var desc:=_label("%s\n%d seats  |  %dkm/h" % [info.name,info.capacity,int(info.speed*1000)],14,ink); desc.size_flags_horizontal=Control.SIZE_EXPAND_FILL; row.add_child(desc)
		var owned := 0
		for train in GameState.trains:
			if train.type == type:
				owned += 1
		var action:=_button("OWNED %d" % owned if info.price == 0 else ("BUY %d" % info.price),"primary"); action.custom_minimum_size=Vector2(88,44); action.disabled=GameState.level<info.unlock
		action.tooltip_text="Unlocks at level %d" % info.unlock if action.disabled else "Buy %s" % info.name
		action.pressed.connect(func(): GameState.buy_train(type)); row.add_child(action)

func _fill_routes(box: VBoxContainer) -> void:
	var create:=_button("+ CREATE ROUTE", "primary"); create.pressed.connect(start_route_builder); box.add_child(create)
	box.add_child(_label("Active lines",13,Color("#6d7770")))
	for route in GameState.routes:
		var origin=GameState.stations[route.origin]; var dest=GameState.stations[route.destination]; var train=GameState.get_train(route.train_id)
		var card:=PanelContainer.new(); card.add_theme_stylebox_override("panel",_panel_style(Color("#fffdf7"),14,Color("#eadcc1"),1,false)); box.add_child(card)
		var copy="%s  to  %s\n%s  |  %d km  |  %d trips" % [origin.name,dest.name,GameState.TRAIN_TYPES[train.type].name,GameState.route_distance(route.origin,route.destination),route.trips]
		card.add_child(_label(copy,14,ink))
	if GameState.routes.size() == 0: box.add_child(_label("Your first line is waiting to be built.",15,Color("#6d7770")))

func _fill_stations(box: VBoxContainer) -> void:
	box.add_child(_label("Tap a place to manage it",13,Color("#6d7770")))
	for station_id in GameState.stations:
		var station:Dictionary=GameState.stations[station_id]
		var row:=HBoxContainer.new(); row.add_theme_constant_override("separation",8); box.add_child(row)
		var copy:=_label("%s\n%s station  |  L%d" % [station.name,station.kind.capitalize(),station.level],14,ink); copy.size_flags_horizontal=Control.SIZE_EXPAND_FILL; row.add_child(copy)
		var action:=_button("OPEN" if station.unlocked else "SURVEY 500","secondary"); action.custom_minimum_size=Vector2(104,43)
		action.pressed.connect(func():
			if station.unlocked: show_station(station_id)
			else: GameState.unlock_station(station_id)
		); row.add_child(action); _divider(box)

func _fill_company(box: VBoxContainer) -> void:
	box.add_child(_label("LINE & LANTERN RAILWAYS",13,coral))
	box.add_child(_label("A growing network, made one good connection at a time.",18,ink))
	var stats:=PanelContainer.new(); stats.add_theme_stylebox_override("panel",_panel_style(Color("#f1ead8"),14,Color.TRANSPARENT,0,false)); stats.add_child(_label("Passengers carried     %d\nLifetime earnings       %d\nRoutes in service         %d\nTrains owned              %d" % [GameState.total_passengers,GameState.total_earned,GameState.routes.size(),GameState.trains.size()],15,ink)); box.add_child(stats)
	box.add_child(_label("NEXT UNLOCK",12,Color("#6d7770")))
	box.add_child(_label("Level %d: %s" % [GameState.level+1,"Cedar Regional" if GameState.level < 2 else "Network expansion"],16,moss))

func _on_station_pressed(station_id: String) -> void:
	if route_build_mode:
		if route_origin == "":
			route_origin=station_id; selected_station=station_id; show_toast("Origin selected. Choose a destination.")
		elif route_origin != station_id:
			route_destination=station_id; selected_station=station_id; show_route_confirmation()
		return
	show_station(station_id)

func show_station(station_id: String) -> void:
	selected_station=station_id; active_tab="Map"
	var s:Dictionary=GameState.stations[station_id]
	var box:=_clear_sheet()
	var top:=HBoxContainer.new(); var title:=_label(s.name,22,ink); title.size_flags_horizontal=Control.SIZE_EXPAND_FILL; top.add_child(title); var close:=_button("X","secondary"); close.custom_minimum_size=Vector2(42,42); close.pressed.connect(close_sheet); top.add_child(close); box.add_child(top)
	box.add_child(_label("%s station  |  Level %d  |  %d daily passengers" % [s.kind.capitalize(),s.level,s.demand],14,Color("#6d7770")))
	var scene:=PanelContainer.new(); scene.custom_minimum_size=Vector2(0,94); scene.add_theme_stylebox_override("panel",_panel_style(s.color,15,Color.TRANSPARENT,0,false)); scene.add_child(_label("Platform %d  •  %s" % [s.level,"Busy interchange" if s.level>2 else "Quietly growing"],16,paper)); box.add_child(scene)
	var upgrade:=_button("UPGRADE STATION  %d" % (240*s.level),"primary"); upgrade.disabled=s.level>=4; upgrade.pressed.connect(func(): GameState.upgrade_station(station_id); show_station(station_id)); box.add_child(upgrade)
	var route:=_button("CREATE A ROUTE FROM HERE","secondary"); route.pressed.connect(func(): close_sheet(); start_route_builder(station_id)); box.add_child(route)
	_show_sheet()

func start_route_builder(origin := "") -> void:
	close_sheet(); route_build_mode=true; route_origin=origin; selected_station=origin
	show_toast("%s" % ("Choose a destination station." if origin != "" else "Choose the origin station."))

func show_route_confirmation() -> void:
	var box:=_clear_sheet(); var origin:Dictionary=GameState.stations[route_origin]; var dest:Dictionary=GameState.stations[route_destination]
	box.add_child(_label("Open a new line",22,ink)); box.add_child(_label("%s  to  %s\n%d km track construction" % [origin.name,dest.name,GameState.route_distance(route_origin,route_destination)],15,Color("#6d7770")))
	var available:=GameState.get_available_trains()
	if available.is_empty():
		box.add_child(_label("No available trains. Buy another train first.",15,coral)); var fleet:=_button("VIEW FLEET","primary"); fleet.pressed.connect(func(): show_tab("Trains")); box.add_child(fleet)
	else:
		box.add_child(_label("ASSIGN A TRAIN",12,Color("#6d7770")))
		for train in available:
			var info:Dictionary=GameState.TRAIN_TYPES[train.type]
			var cost:=GameState.route_construction_cost(route_origin,route_destination)
			var choose:=_button("%s  •  %d seats  •  BUILD %d" % [info.name,info.capacity,cost],"primary")
			choose.pressed.connect(func():
				if GameState.create_route(route_origin,route_destination,train.id): close_sheet()
			); box.add_child(choose)
	var cancel:=_button("CANCEL","secondary"); cancel.pressed.connect(close_sheet); box.add_child(cancel); _show_sheet()

func show_pause() -> void:
	var box:=_clear_sheet(); box.add_child(_label("Game paused",22,ink)); box.add_child(_label("Your network will be right where you left it.",15,Color("#6d7770")))
	var resume:=_button("RESUME","primary"); resume.pressed.connect(close_sheet); box.add_child(resume)
	var save:=_button("SAVE NOW","secondary"); save.pressed.connect(func(): GameState.save_game(); show_toast("Progress saved.")); box.add_child(save)
	var settings_button:=_button("SETTINGS","secondary"); settings_button.pressed.connect(show_settings); box.add_child(settings_button); _show_sheet()

func show_settings() -> void:
	var box:=_clear_sheet(); box.add_child(_label("Settings",22,ink)); box.add_child(_label("Music volume",14,ink))
	var music:=HSlider.new(); music.min_value=0; music.max_value=1; music.step=.05; music.value=GameState.settings.music; music.value_changed.connect(func(v): GameState.settings.music=v; GameState.save_game()); box.add_child(music)
	box.add_child(_label("Sound effects volume",14,ink)); var sfx:=HSlider.new(); sfx.min_value=0; sfx.max_value=1; sfx.step=.05; sfx.value=GameState.settings.sfx; sfx.value_changed.connect(func(v): GameState.settings.sfx=v; GameState.save_game()); box.add_child(sfx)
	for setting in [["vibration","Vibration"],["notifications","Notifications"]]:
		var check:=CheckBox.new(); check.text=setting[1]; check.button_pressed=GameState.settings[setting[0]]; check.toggled.connect(func(on): GameState.settings[setting[0]]=on; GameState.save_game()); box.add_child(check)
	var reset:=_button("RESET SAVE DATA","secondary"); reset.pressed.connect(show_reset_confirmation); box.add_child(reset)
	var back:=_button("BACK","primary"); back.pressed.connect(show_pause); box.add_child(back); _show_sheet()

func show_reset_confirmation() -> void:
	var box:=_clear_sheet(); box.add_child(_label("Reset all progress?",22,coral)); box.add_child(_label("This starts a new company and cannot be undone.",15,ink)); var yes:=_button("YES, START OVER","primary"); yes.pressed.connect(func(): GameState.reset_game(); close_sheet(); show_main_menu()); box.add_child(yes); var no:=_button("CANCEL","secondary"); no.pressed.connect(show_settings); box.add_child(no); _show_sheet()

func show_main_menu() -> void:
	var box:=_clear_sheet(); box.add_child(_label("LINE & LANTERN",27,ink)); box.add_child(_label("Railway Company",16,coral)); box.add_child(_label("Build a railway that brings the country closer together.",16,Color("#6d7770")))
	var continue_button:=_button("CONTINUE","primary"); continue_button.pressed.connect(func(): close_sheet(); if GameState.tutorial_step == 0: show_tutorial()); box.add_child(continue_button)
	var new_game:=_button("NEW GAME","secondary"); new_game.pressed.connect(func(): GameState.reset_game(); close_sheet(); show_tutorial()); box.add_child(new_game)
	var settings_button:=_button("SETTINGS","secondary"); settings_button.pressed.connect(show_settings); box.add_child(settings_button); _show_sheet()

func show_tutorial() -> void:
	var box:=_clear_sheet(); box.add_child(_label("Your first line",22,ink));
	if GameState.tutorial_step == 0:
		box.add_child(_label("Meadowfield is already linked to Briarwick. Watch your Willow Railcar make its first journeys, then tap a station to explore upgrades.",16,Color("#536562"))); var go:=_button("LET'S BEGIN","primary"); go.pressed.connect(func(): GameState.tutorial_step=1; GameState.save_game(); close_sheet()); box.add_child(go)
	else:
		box.add_child(_label("Your network is earning money. When you are ready, buy another train and open a new connection.",16,Color("#536562"))); var go:=_button("GOT IT","primary"); go.pressed.connect(close_sheet); box.add_child(go)
	var skip:=_button("SKIP TUTORIAL","secondary"); skip.pressed.connect(func(): GameState.tutorial_step=3; GameState.save_game(); close_sheet()); box.add_child(skip); _show_sheet()

func show_toast(message: String) -> void:
	toast_label.text=message; toast.visible=true; toast.modulate.a=0.0
	var tween:=create_tween(); tween.tween_property(toast,"modulate:a",1.0,.15); tween.tween_interval(2.2); tween.tween_property(toast,"modulate:a",0.0,.25); tween.tween_callback(func(): toast.visible=false)

func _on_reward(amount: int, message: String) -> void:
	show_toast(("+%d coins  •  " % amount if amount > 0 else "") + message)

func _on_level_up(new_level: int) -> void:
	show_toast("Level %d reached. +180 coins" % new_level)
