extends Control

signal station_pressed(station_id: String)

var pan := Vector2.ZERO
var zoom := 1.0
var dragging := false
var drag_start := Vector2.ZERO
var focus_station := ""

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP
	set_process(true)

func _process(_delta: float) -> void:
	queue_redraw()

func world_to_screen(point: Vector2) -> Vector2:
	var base := Vector2(size.x * 0.5, size.y * 0.5)
	return base + (point - Vector2(0.5, 0.5)) * Vector2(size.x * 1.08, size.y * 1.14) * zoom + pan

func screen_to_world(point: Vector2) -> Vector2:
	var base := Vector2(size.x * 0.5, size.y * 0.5)
	return ((point - base - pan) / (Vector2(size.x * 1.08, size.y * 1.14) * zoom)) + Vector2(0.5, 0.5)

func _gui_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch or event is InputEventMouseButton:
		var pressed: bool = event.pressed
		var position: Vector2 = event.position
		if pressed:
			dragging = true
			drag_start = position
		else:
			if dragging and drag_start.distance_to(position) < 14.0:
				for station_id in GameState.stations:
					if not GameState.stations[station_id].unlocked:
						continue
					if world_to_screen(GameState.stations[station_id].pos).distance_to(position) < 36.0:
						station_pressed.emit(station_id)
			dragging = false
	elif event is InputEventScreenDrag or event is InputEventMouseMotion and dragging:
		if dragging:
			pan += event.relative
			pan = pan.clamp(Vector2(-size.x * 0.32, -size.y * 0.32), Vector2(size.x * 0.32, size.y * 0.32))
	elif event is InputEventMagnifyGesture:
		zoom = clamp(zoom * event.factor, 0.78, 1.55)
		queue_redraw()

func _draw() -> void:
	# A hand-drawn miniature landscape, intentionally built from layered simple forms.
	draw_rect(Rect2(Vector2.ZERO, size), Color("#b9dbe0"))
	for i in 9:
		var cloud_pos := Vector2(fposmod(i * 173.0 + GameState.elapsed * 5.0, size.x + 180.0) - 90.0, 28.0 + (i % 4) * 64.0)
		draw_circle(cloud_pos, 30.0, Color(1,1,1,0.14))
		draw_circle(cloud_pos + Vector2(28,7), 22.0, Color(1,1,1,0.12))
	var land := PackedVector2Array([Vector2(-30, size.y * .12), Vector2(size.x*.30, 0), Vector2(size.x+.4, size.y*.06), Vector2(size.x+40,size.y+20), Vector2(-30,size.y+20)])
	draw_colored_polygon(land, Color("#d3d899"))
	# Terrain parcels.
	for i in 10:
		var x := fposmod(i * 119.0 + 18.0, size.x + 100.0) - 50.0
		var y := 165.0 + (i % 5) * 118.0
		draw_rect(Rect2(Vector2(x,y), Vector2(105,76)), [Color("#b9cc72"),Color("#e4ce83"),Color("#a7c17e")][i % 3], true)
		draw_line(Vector2(x,y+13), Vector2(x+105,y+13), Color(1,1,1,.15), 1.0)
	# River with simple meanders.
	var river := PackedVector2Array([Vector2(size.x*.67,-10),Vector2(size.x*.82,100),Vector2(size.x*.69,220),Vector2(size.x*.86,350),Vector2(size.x*.74,480),Vector2(size.x*.90,size.y+20),Vector2(size.x*.78,size.y+20),Vector2(size.x*.60,490),Vector2(size.x*.72,355),Vector2(size.x*.55,224),Vector2(size.x*.69,102),Vector2(size.x*.54,-10)])
	draw_colored_polygon(river, Color("#82c7d3"))
	# forests, roads and houses
	for i in 28:
		var p := Vector2(fposmod(i*73.0+22.0,size.x-20.0)+10.0, 135.0+fposmod(i*113.0,size.y-155.0))
		if p.x < size.x*.54 or p.y > size.y*.50:
			draw_circle(p, 9 + (i%3)*2, [Color("#4e8057"),Color("#5d945d"),Color("#3f704e")][i%3])
			draw_circle(p-Vector2(2,4), 5, Color(1,1,1,.08))
	draw_line(Vector2(-20,size.y*.62), Vector2(size.x+20,size.y*.33), Color("#c6ae82"), 9)
	draw_line(Vector2(-20,size.y*.62), Vector2(size.x+20,size.y*.33), Color("#e5d3a5"), 4)
	# routes beneath stations
	for route in GameState.routes:
		if not GameState.stations.has(route.origin) or not GameState.stations.has(route.destination): continue
		var a := world_to_screen(GameState.stations[route.origin].pos)
		var b := world_to_screen(GameState.stations[route.destination].pos)
		draw_line(a,b,Color("#4f514f"),8.0,true)
		draw_line(a,b,Color("#d8d0bd"),3.0,true)
		for t in range(1,9):
			var q := a.lerp(b, t/9.0)
			var side := (b-a).normalized().orthogonal() * 5.0
			draw_line(q-side,q+side,Color("#785e53"),1.5)
		_draw_train(route, a, b)
	# stations on top
	for station_id in GameState.stations:
		var s = GameState.stations[station_id]
		var p := world_to_screen(s.pos)
		if not s.unlocked:
			draw_circle(p, 20, Color("#728480"))
			draw_string(ThemeDB.fallback_font, p + Vector2(-7,6), "?", HORIZONTAL_ALIGNMENT_LEFT, -1, 20, Color.WHITE)
			continue
		_draw_station(p, s, station_id == focus_station)

func _draw_station(p: Vector2, s: Dictionary, focused: bool) -> void:
	var scale: float = 1.0 + (float(s.level) - 1.0) * .12
	if focused:
		draw_circle(p, 34*scale, Color("#fff4c6"))
	draw_circle(p + Vector2(2,9), 25*scale, Color(0,0,0,.16))
	draw_rect(Rect2(p + Vector2(-22,-5)*scale, Vector2(44,13)*scale), Color("#f1e3c2"), true)
	draw_rect(Rect2(p + Vector2(-14,-22)*scale, Vector2(28,22)*scale), s.color, true)
	draw_colored_polygon(PackedVector2Array([p+Vector2(-18,-22)*scale,p+Vector2(0,-34)*scale,p+Vector2(18,-22)*scale]), Color("#a74d47"))
	draw_line(p+Vector2(-30,12)*scale,p+Vector2(30,12)*scale,Color("#4e514f"),5)
	draw_string(ThemeDB.fallback_font, p+Vector2(-39,42)*scale, s.name, HORIZONTAL_ALIGNMENT_CENTER,78,12,Color("#345050"))

func _draw_train(route: Dictionary, a: Vector2, b: Vector2) -> void:
	var train := GameState.get_train(route.train_id)
	if train.is_empty(): return
	var t: float = route.progress
	var p := a.lerp(b,t)
	var angle := (b-a).angle()
	var info: Dictionary = GameState.TRAIN_TYPES[train.type]
	draw_set_transform(p, angle, Vector2.ONE)
	draw_rect(Rect2(-23,-8,46,16), Color(0,0,0,.20), true)
	draw_rect(Rect2(-21,-11,42,16), info.color, true)
	draw_rect(Rect2(-18,-9,6,5), info.accent, true)
	draw_rect(Rect2(-9,-9,6,5), info.accent, true)
	draw_rect(Rect2(0,-9,6,5), info.accent, true)
	draw_rect(Rect2(9,-9,6,5), info.accent, true)
	draw_circle(Vector2(-13,7),3,Color("#363b43")); draw_circle(Vector2(13,7),3,Color("#363b43"))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
